<template>
  <div id="myRef">
      <h1>myRef组件</h1>
      <input type="text" v-if="inpVisible" @blur='showBtn' ref="inpRef">
      <button v-else @click="showInp">展示输入框</button>
  </div>
</template>

<script>
export default {
    data() {
        return {
            inpVisible: false
        }
    },
    methods: {
        showInp() {
            this.inpVisible = true
            this.$nextTick( () => {
                this.$refs.inpRef.focus()
            })
        },
        showBtn() {
            this.inpVisible = false
        }
    }
}
</script>

<style>

</style>