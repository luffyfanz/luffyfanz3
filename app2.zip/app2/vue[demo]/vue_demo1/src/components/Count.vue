<template>
  <div>
    <h1>Count组件</h1>
    <div>{{ count }}</div>
    <div>{{ msg }}</div>
    <div v-if="use">
      <div>{{ user.name }}</div>
    </div>
    <div>{{ person.name }}</div>
    <button @click="add">+1</button>
    <button @click="addFather">父组件+1</button>
    <hr />
  </div>
</template>

<script>
export default {
  props: ["init", "msg", "use"],
  data() {
    return {
      count: this.init,
      user: this.use,
      num: 0,
      person: {
        name: "aaa",
        age: "12",
      },
    };
  },
  methods: {
    add() {
      this.count += 1;
      console.log(this.user);
    },
    addFather() {
      this.num += 1;
      this.$emit("numAdd", this.num);
    },
  },
};
</script>

<style lang="less" scoped>
h1 {
  color: white;
}
</style>>
