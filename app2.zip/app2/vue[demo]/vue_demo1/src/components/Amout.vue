<template>
  <div id="amout">
    <h1>Amout组件</h1>
    <div class="goods">
      <ul>
        <li v-for="item in goodList" :key="item.id" class="single">
          <span>{{ item.id }}</span>
          <span>名字{{ item.name }}</span>
          <span>状态{{ item.state }}</span>
          <span>单价:{{ item.price }}￥</span>
          <span>
            <button @click="sub(item.id)">-1</button>
            数量:{{ item.count }}
            <button @click="add(item.id)">+1</button>
          </span>
          <span>总价:{{ item.price * item.count }}￥</span>
        </li>
      </ul>
      总价：{{ amout }} ￥
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      goodList: [
        { id: 1, name: "a", state: true, price: 10, count: 1 },
        { id: 2, name: "b", state: true, price: 20, count: 2 },
        { id: 3, name: "c", state: false, price: 30, count: 1 },
        { id: 4, name: "d", state: true, price: 40, count: 3 },
        { id: 5, name: "e", state: false, price: 40, count: 3 },
      ],
    };
  },
  methods: {
    sub(id) {
      this.goodList[id - 1].count--;
    },
    add(id) {
      this.goodList[id - 1].count++;
    },
  },
  computed: {
    amout() {
      //   let a = 0;
      //     // 旧：通过forEach来计算总价
      //   this.goodList
      //     .filter((item) => item.state == true)
      //     .forEach((item) => {
      //       a += item.price * item.count;
      //     });

      // 新：通过reduce来计算总价
    //   let a = this.goodList
    //     .filter((item) => item.state == true)
    //     .reduce((total, item) => {
    //       return (total += item.price * item.count);
    //     }, 0);
    //   return a;
    // 精简：
    let a = this.goodList.filter(item => item.state == true).reduce((total,item) => total += item.price * item.count, 0)
    return a
    },
  },
};
</script>

<style lang="less" scoped>
* {
  margin: 0;
  padding: 0;
}
li {
  list-style: none;
}
ul {
  width: 500px;
  height: 400px;
  background-color: green;
  > li {
    > :nth-child(1) {
      width: 30px;
    }
    > :nth-child(2) {
      width: 50px;
    }
    width: 100%;
    height: 50px;
    background-color: bisque;
    margin-bottom: 10px;
    span {
      display: inline-block;
      width: 100px;
      height: 50px;
      line-height: 50px;
    }
  }
}
</style>