<template>
  <div id="app">
    <!-- <nav> -->
      <!-- <router-link to="/">Home</router-link> | -->
      <!-- <router-link to="/about">About</router-link> -->
    <!-- </nav> -->
    <!-- <router-view/> -->
    <h1>App根组件</h1>
    <div class="left">
      <!-- <Home></Home> -->
      <Third></Third>
    </div>
    <div class="right">
      <!-- <About></About> -->
      <Amout></Amout>
    </div>
  </div>
</template>

<script>
import Home from './views/HomeView.vue'
import About from './views/AboutView.vue'
import Third from './views/Third.vue'
import Amout from './components/Amout.vue'
export default {
  components: {
    Home,
    About,
    Third,
    Amout
  }
}
</script>

<style lang="less">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
.left {
  width: 500px;
  height: 500px;
  background-color: orange;
  float: left;
  margin-right: 20px;
}
.right {
  width: 500px;
  height: 500px;
  float: left;
  background-color: skyblue;
}
</style>
