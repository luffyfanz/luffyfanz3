<template>
  <div id="third">
      <h1>Third组件</h1>
      <hr>
    <MyRef></MyRef>

  </div>
</template>

<script>
export default {};
</script>

<style lang="less" scoped>
#third {
  width: 500px;
  height: 500px;
  background-color: orange;
  float: left;
  margin-right: 20px;
}
</style>