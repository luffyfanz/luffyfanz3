<template>
  <div class="home">
    <h1>This is a home page</h1>
    <h1 ref="myH1">{{fromAboutString}}</h1>
    <button @click="changeTop">改变上方的值</button>
    <button @click="changeCount">改变count子组件的值</button>
    <hr>
    <MyCount :init="6" ref="countRef"></MyCount>
    <MyCount :use='userInfo'></MyCount>
  </div>
</template>

<script>
// @ is an alias to /src
// import Count from '../components/Count.vue'
import bus from './eventBus.js'

export default {
  data() {
    return {
      // student: [{ name: "tom", age: 13, id: 1 },{name: "peter", age: 13, id: 2 }],
      userInfo: {name: 'jack', age: 12, id: 1},
      fromAboutString: '初始值'
    }
  },
  created() {
    bus.$on('shareAbout', val => {
      console.log('接收到值');
      this.fromAboutString = val
    })
  },
  methods: {
    // bus.$on('shareAbout', val => {
    //   this.fromAboutString = val
    // }),
    changeTop() {
      this.$refs.myH1.textContent = '1234'
    },
    changeCount() {
      this.$refs.countRef.count = 1
    }
  }
};
</script>
