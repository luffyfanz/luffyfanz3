<template>
  <div class="about">
    <h1>This is an about page</h1>
    <h1>{{num}}</h1>
    <button @click="sendBro">向Home传值</button>
    <hr>
    <MyCount :init='9'></MyCount>
    <!-- <MyCount :msg='message'></MyCount> -->
    <MyCount @numAdd="getSon"></MyCount>
    
  </div>
</template>

<script>
import bus from './eventBus.js'
export default {
  data() {
    return {
      message: 'hello',
      num: 0,
      busString: '来自about的数据'
    }
  },
  methods: {
    getSon(val) {
      this.num = val
      console.log('numAdd事件被触发了');
    },
    sendBro() {
      console.log('开始传值');
      bus.$emit('shareAbout', this.busString)
    }
  }
}
</script>


<style lang="less" scoped>
  h1 {
    color: blue
  }
</style>