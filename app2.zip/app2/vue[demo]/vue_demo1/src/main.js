import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Count from './components/Count.vue'
import Ref from './components/Ref.vue'
import './plugins/element.js'

Vue.config.productionTip = false
Vue.component('MyCount',Count)
Vue.component('MyRef', Ref)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
